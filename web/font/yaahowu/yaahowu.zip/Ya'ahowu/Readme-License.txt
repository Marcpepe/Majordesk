By downloading and/or installing Ya'ahowu font you agree to this license:
1. This font is freeware. You can use it free for personal and commercial use in any media online or offline, such as websites, applications, books, flyier, etc.
2. The font files are not allowed to modify without written permission from the creator, Situjuh Nazara.
3. This font may be redistributed, shared, repackaged or included in any online or offline achieve, font collection, and website 
4. This font is allowed to be embedded in a PDF document
5. The creator of this font is not legally responsible for any damage resulting from the use of this font.
------------------------
Ya'ahowu is created by Situjuh Nazara
Email: c7nazara[at]gmail.com
Webiste: http://c7n1.wordpress.com
Facebook: http://facebook.com/situjuh.nazara
Twitter: @c7nazara
-------------------------
If you feel happy using Ya'ahowu font, I appreciate your donation via paypal(c7nazara[at]gmail.com)